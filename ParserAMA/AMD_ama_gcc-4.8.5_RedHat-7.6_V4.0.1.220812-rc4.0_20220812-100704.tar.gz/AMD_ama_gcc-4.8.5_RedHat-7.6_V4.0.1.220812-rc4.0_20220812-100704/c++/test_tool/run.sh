#!/bin/bash
__AMA_FPGA_LDDS_SNAPSHOT_CACHE_CNT__=20 __AMA_FPGA_LDDS_INDEX_SNAPSHOT_CACHE_CNT__=20 __AMA_FPGA_LDDS_ORDERQUEUE_CACHE_CNT__=20 __AMA_FPGA_LDDS_TICK_CACHE_CNT__=20 LD_LIBRARY_PATH=../lib:$LD_LIBRARY_PATH ./bin/ama_test --log-to-console --cfg-name ./etc/ama.json  --data-to-console --data-to-csv --snapshot --index-snapshot --tick-order --tick-execution --bond-snapshot --hk-snapshot --order-book 

