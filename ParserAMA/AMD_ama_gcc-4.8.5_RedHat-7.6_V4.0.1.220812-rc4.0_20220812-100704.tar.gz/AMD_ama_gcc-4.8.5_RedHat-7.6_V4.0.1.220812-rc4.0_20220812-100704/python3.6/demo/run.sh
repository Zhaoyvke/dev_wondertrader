#!/bin/bash
LD_LIBRARY_PATH=./lib:../../c++/lib:$LD_LIBRARY_PATH PYTHONPATH=../lib:$PYTHONPATH python3 ./ama_demo.py
