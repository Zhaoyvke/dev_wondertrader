#!/bin/bash
LD_LIBRARY_PATH=../lib:../../c++/lib/:$LD_LIBRARY_PATH PYTHONPATH=../lib:$PYTHONPATH python ./ama_demo.py
