#!/bin/bash

#compile
javac -encoding utf-8 -classpath ../ama.jar ./*.java -d .
jar cvf demo.jar ./

# run
export LD_LIBRARY_PATH=../lib:../../c++/lib:$LD_LIBRARY_PATH
export CLASSPATH=$CLASSPATH:../ama.jar:./demo.jar
java -cp .:../lib:../ama.jar:demo.jar demo.ama.AmaDemo
